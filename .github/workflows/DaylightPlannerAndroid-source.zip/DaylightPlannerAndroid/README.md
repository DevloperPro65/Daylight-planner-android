# Daylight Planner Android

Android WebView wrapper for the live Daylight Planner site, with Android `AlarmManager` and `NotificationManager` for native local notifications. The reminders are scheduled by Android and do not depend on a browser notification API or an open tab.

## Build an APK on GitHub
1. Upload this project folder to the repository `DevloperPro65/Daylight-planner-android`.
2. Open **Actions → Build Daylight Planner APK → Run workflow** (or push to `main`).
3. Download the `Daylight-Planner-debug-APK` artifact from the completed workflow run.
4. Install the APK on Android and allow notifications when prompted.

The GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. This produces a debug APK for personal use, not a Play Store-signed release.

## Important
- Android 13+ requires notification permission.
- Android 12+ may require exact-alarm access in system settings. Without that access, Android can delay alarms while idle.
- Battery-management policies from some phone manufacturers can still delay delivery.
