package ai.daylightplanner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object AlarmScheduler {
    fun schedule(context: Context, id: String, label: String, time: Long, repeatDaily: Boolean) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("id", id)
            putExtra("label", label)
            putExtra("repeatDaily", repeatDaily)
            putExtra("scheduledAt", time)
        }
        val pi = PendingIntent.getBroadcast(context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
                } else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            } else manager.setExact(AlarmManager.RTC_WAKEUP, time, pi)
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        }
    }

    fun cancel(context: Context, id: String) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        pi.cancel()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val label = intent.getStringExtra("label") ?: "Planner reminder"
        val repeatDaily = intent.getBooleanExtra("repeatDaily", false)
        val notification = NotificationCompat.Builder(context, "daylight_reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(label)
            .setContentText("Your Daylight Planner reminder is due.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(id.hashCode(), notification) } catch (_: SecurityException) { }
        if (repeatDaily) {
            val prefs = context.getSharedPreferences("daylight_native_alarms", Context.MODE_PRIVATE)
            val scheduledAt = intent.getLongExtra("scheduledAt", System.currentTimeMillis())
            val next = scheduledAt + 24L * 60L * 60L * 1000L
            AlarmScheduler.schedule(context, id, prefs.getString("label_$id", label) ?: label, next, true)
            prefs.edit().putLong("time_$id", next).apply()
        } else {
            val prefs = context.getSharedPreferences("daylight_native_alarms", Context.MODE_PRIVATE)
            val ids = prefs.getStringSet("ids", emptySet())?.toMutableSet() ?: mutableSetOf()
            ids.remove(id)
            prefs.edit().putStringSet("ids", ids).remove("label_$id").remove("time_$id").remove("repeat_$id").apply()
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("daylight_native_alarms", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("ids", emptySet()) ?: emptySet()
        val now = System.currentTimeMillis()
        ids.forEach { id ->
            val old = prefs.getLong("time_$id", 0L)
            val repeat = prefs.getBoolean("repeat_$id", false)
            if (old > 0L && (repeat || old > now)) {
                val next = if (old > now) old else {
                    var candidate = old
                    while (candidate <= now) candidate += 24L * 60L * 60L * 1000L
                    candidate
                }
                AlarmScheduler.schedule(context, id, prefs.getString("label_$id", "Planner reminder") ?: "Planner reminder", next, repeat)
            }
        }
    }
}
