package ai.daylightplanner

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermission()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.setSupportZoom(false)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativeAlarms(this), "DaylightNative")
        setContentView(webView)
        webView.loadUrl("https://daylight-planner-dp1n0x.v2.appdeploy.ai/")
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("daylight_reminders", "Daylight reminders", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Task and routine reminders from Daylight Planner"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class NativeAlarms(private val context: Context) {
    @JavascriptInterface
    fun scheduleAlarm(id: String, label: String, epochMillis: Long, repeatDaily: Boolean): Boolean {
        if (id.isBlank() || label.isBlank() || epochMillis <= 0L) return false
        val prefs = context.getSharedPreferences("daylight_native_alarms", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(id)
        prefs.edit().putStringSet("ids", ids).putString("label_$id", label.take(100))
            .putLong("time_$id", epochMillis).putBoolean("repeat_$id", repeatDaily).apply()
        AlarmScheduler.schedule(context, id, label.take(100), epochMillis, repeatDaily)
        return true
    }

    @JavascriptInterface
    fun cancelAlarm(id: String): Boolean {
        AlarmScheduler.cancel(context, id)
        val prefs = context.getSharedPreferences("daylight_native_alarms", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.remove(id)
        prefs.edit().putStringSet("ids", ids).remove("label_$id").remove("time_$id").remove("repeat_$id").apply()
        return true
    }

    @JavascriptInterface
    fun requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(AlarmManager::class.java)
            if (!manager.canScheduleExactAlarms()) {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
    }
}
